import React, { useState, useEffect } from 'react';

const AppointmentsList = ({ onEdit }) => {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    const storedAppointments = JSON.parse(localStorage.getItem('appointments')) || [];
    setAppointments(storedAppointments);
  }, []);

  const handleDelete = (index) => {
    const updatedAppointments = appointments.filter((_, i) => i !== index);
    localStorage.setItem('appointments', JSON.stringify(updatedAppointments));
    setAppointments(updatedAppointments);
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-xl shadow-md mt-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Turnos Reservados</h2>
      {appointments.length === 0 ? (
        <p className="text-gray-500">No hay turnos reservados aún</p>
      ) : (
        <ul className="space-y-4">
          {appointments.map((appointment, index) => (
            <li key={index} className="border-b pb-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-medium">{appointment.name}</p>
                  <p className="text-sm text-gray-600">{appointment.service}</p>
                  <p className="text-sm">{appointment.date} a las {appointment.time}</p>
                </div>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => onEdit(index)}
                    className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
                  >
                    Editar
                  </button>
                  <button 
                    onClick={() => handleDelete(index)}
                    className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AppointmentsList;