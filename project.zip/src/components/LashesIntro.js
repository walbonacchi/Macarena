const LashesIntro = () => {
  return (
    <div className="flex flex-col items-center justify-center p-8 bg-pink-50">
      <div className="mb-6">
        <img 
          src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0i7o0OrU3SvywDhA4KtNVcgeG7fQn92ZEUMjC" 
          alt="Maca Lashes Logo"
          className="w-48 h-auto"
        />
      </div>
      <h1 className="text-4xl font-bold text-pink-600 mb-2">Maca Lashes</h1>
      <p className="text-gray-600">Reserva tu cita para unas pestañas de ensueño</p>
    </div>
  );
};

export default LashesIntro;

// DONE