import React, { useEffect, useState } from 'react';

const SplashScreen = ({ onFinish }) => {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      onFinish();
    }, 3000);

    // Crear elemento audio de manera nativa
    const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3');
    audio.play().catch(error => console.log('Error al reproducir sonido:', error));

    return () => {
      clearTimeout(timer);
      audio.pause();
    };
  }, [onFinish]);

  return visible ? (
    <div className="fixed inset-0 flex items-center justify-center bg-gradient-to-br from-pink-100 to-pink-300 z-50">
      <div className="animate-pulse">
        <img 
          src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0i7o0OrU3SvywDhA4KtNVcgeG7fQn92ZEUMjC" 
          alt="Maca Lashes Logo"
          className="w-64 h-auto transition-transform duration-1000 hover:scale-110"
        />
        <h1 className="text-4xl font-bold text-center mt-6 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
          MACA LASHES
        </h1>
      </div>
    </div>
  ) : null;
};

export default SplashScreen;

// DONE