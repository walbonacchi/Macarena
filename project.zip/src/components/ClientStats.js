const ClientStats = ({ clients = [], appointments = [] }) => {
  const totalClients = clients.length;
  const totalAppointments = appointments.length;
  const servicesCount = appointments.reduce((acc, appointment) => {
    if (appointment && appointment.service) {
      acc[appointment.service] = (acc[appointment.service] || 0) + 1;
    }
    return acc;
  }, {});

  const nextAppointment = appointments.length > 0 ? 
    new Date(appointments[0].date).toLocaleDateString() : 'N/A';

  return (
    <div className="bg-white p-6 rounded-xl shadow-md mb-6">
      <h3 className="text-xl font-semibold text-pink-700 mb-4">Estadísticas</h3>
      
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-pink-50 p-4 rounded-lg">
          <p className="text-gray-500">Total Clientes</p>
          <p className="text-3xl font-bold text-pink-600">{totalClients}</p>
        </div>

        <div className="bg-pink-50 p-4 rounded-lg">
          <p className="text-gray-500">Turnos Reservados</p>
          <p className="text-3xl font-bold text-pink-600">{totalAppointments}</p>
        </div>

        <div className="bg-pink-50 p-4 rounded-lg">
          <p className="text-gray-500">Próxima cita</p>
          <p className="text-3xl font-bold text-pink-600">{nextAppointment}</p>
        </div>
      </div>

      {totalAppointments > 0 && (
        <div className="mt-6">
          <h4 className="font-medium text-gray-700 mb-2">Servicios más solicitados</h4>
          <div className="space-y-2">
            {Object.entries(servicesCount).map(([service, count]) => (
              <div key={service} className="flex items-center">
                <span className="w-32 text-gray-600 capitalize">{service}</span>
                <div className="flex-1 bg-gray-200 rounded-full h-4">
                  <div 
                    className="bg-pink-500 h-4 rounded-full" 
                    style={{ width: `${(count / totalAppointments) * 100}%` }}
                  ></div>
                </div>
                <span className="ml-2 text-gray-700">{count}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientStats;

// DONE