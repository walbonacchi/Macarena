import React, { useState } from 'react';

const ClientList = ({ clients, onEdit, onDelete, onSelect, isAppointmentList }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (client.phone && client.phone.includes(searchTerm))
  );

  return (
    <div className="max-w-4xl mx-auto bg-white p-6 rounded-xl shadow-md">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold text-pink-700">
          {isAppointmentList ? 'Lista de Turnos' : 'Lista de Clientes'}
        </h3>
        <input
          type="text"
          placeholder={isAppointmentList ? 'Buscar turnos' : 'Buscar por nombre o teléfono'}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-pink-500 flex-1 max-w-md"
        />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-pink-50 text-pink-700">
            <tr>
              <th className="px-4 py-2 text-left">Nombre</th>
              {!isAppointmentList && <th className="px-4 py-2 text-left">Teléfono</th>}
              {isAppointmentList && <th className="px-4 py-2 text-left">Servicio</th>}
              {isAppointmentList && <th className="px-4 py-2 text-left">Fecha</th>}
              {isAppointmentList && <th className="px-4 py-2 text-left">Hora</th>}
              <th className="px-4 py-2 text-left">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filteredClients.length > 0 ? (
              filteredClients.map((client, index) => (
                <tr key={index} className="border-b hover:bg-pink-50">
                  <td className="px-4 py-3">{client.name}</td>
                  {!isAppointmentList && <td className="px-4 py-3">{client.phone}</td>}
                  {isAppointmentList && <td className="px-4 py-3 capitalize">{client.service}</td>}
                  {isAppointmentList && <td className="px-4 py-3">{new Date(client.date).toLocaleDateString()}</td>}
                  {isAppointmentList && <td className="px-4 py-3">{client.time}</td>}
                  <td className="px-4 py-3 space-x-2">
                    {!isAppointmentList && (
                      <button
                        onClick={() => onSelect(client)}
                        className="text-green-500 hover:text-green-700 mr-2"
                      >
                        Crear Turno
                      </button>
                    )}
                    <button
                      onClick={() => onEdit(index)}
                      className="text-blue-500 hover:text-blue-700 mr-2"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => onDelete(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={isAppointmentList ? 5 : 3} className="px-4 py-6 text-center text-gray-500">
                  {isAppointmentList ? 'No se encontraron turnos' : 'No se encontraron clientes'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ClientList;